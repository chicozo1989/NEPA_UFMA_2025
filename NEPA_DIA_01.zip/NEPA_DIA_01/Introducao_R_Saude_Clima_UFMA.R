# Introdução ao R
# Arquivo: Introducao_R_para_Pesquisa em Saúde Ambiental
# Objetivo: script didático e passo-a-passo para iniciantes (graduação e pós)
# ---------------------------------------------------------------

# INSTRUÇÕES GERAIS
# - Execute cada linha ou bloco com Ctrl+Enter (Cmd+Enter no Mac).
# - Observe sempre o Console e a aba Environment (Objetos).
# - Se der erro, leia a mensagem: ela costuma dizer o que está faltando.
# ---------------------------------------------------------------
# 1. BOAS-VINDAS E POR QUE O R IMPORTA (contexto curto)
# ---------------------------------------------------------------
# O R é livre, muito usado em estatística, saúde pública, ciências
# ambientais e análise espacial. Com ele você pode:
# - limpar e organizar dados;  - calcular estatísticas;  - criar gráficos;
# - fazer análises temporais e espaciais; - automatizar relatórios.

# ---------------------------------------------------------------
# 2. PRIMEIROS PASSOS: R COMO 'CAIXINHA' DE VALORES (objetos)
# ---------------------------------------------------------------
# No R, tudo que guardamos fica em objetos — pense como "caixinhas".
# Para criar um objeto use o operador <- (seta). Evite sobrescrever sem querer.

meu_primeiro_objeto <- 15    # número
meu_primeiro_objeto          # exibe o conteúdo

# operadores aritméticos básicos
2 + 2   # soma
3 - 1   # subtração
4 * 5   # multiplicação
12 / 3  # divisão
7 ^ 2   # exponenciação
0:10    # sequência de 0 a 10

# operadores de comparação
3 == 3  # igual
5 != 0  # diferente
2 > 9   # maior que
1 < 8   # menor que
5 >= 5  # maior ou igual
4 <= 1  # menor ou igual

# sobrescrevendo objetos (atenção)
meu_primeiro_objeto <- 160
meu_primeiro_objeto

# texto (strings) precisam de aspas
# errado: nome <- usp
# certo:
nome_1 <- "usp"
nome_2 <- 'usp'

nome_1
nome_2

# comparações com strings
nome_1 == nome_2
nome_1 != nome_2

# valores lógicos
verdadeiro <- nome_1 == nome_2
verdadeiro
falso <- nome_1 != nome_2
falso

# valores especiais
TRUE; FALSE; NA; NULL; Inf; -Inf

# ---------------------------------------------------------------
# 3. VETORES E COLEÇÕES
# ---------------------------------------------------------------
# Para guardar várias observações usamos vetores (função c()).
vetor <- c(1,2,3,4,5,6,7,8,9,10)
vetor

nomes <- c("mariana", "pedro", "daniela")
nomes

# comprimento e classe
length(vetor)
class(vetor)
class(nomes)

# indexação: o R começa em 1 (não em 0)
vetor[1]   # primeiro elemento
vetor[5]

# operações vetorizadas (elemento-a-elemento)
vetor + 1
vetor * 2

# ---------------------------------------------------------------
# 4. FUNÇÕES: DANDO ORDENS AO COMPUTADOR
# ---------------------------------------------------------------
# Funções têm nome + parênteses. Dentro do parêntese vão argumentos.
# Funções são aplicadas sobre objetos,normalmente chamados de 'x'
# Cada Função só pode ser aplicada ao tipo de objeto o qual foi designado
# Veja o exemplo, é possível aplicar uma função para arredondar a um objeto
# do tipo character?
round(x = 3.141592)
round(x = 3.141592, digits = 3)

# ajuda sobre funções -> Como saber os argumentos de cada função?
?round
args(round)

# ---------------------------------------------------------------
# 5. LENDO E SALVANDO DADOS (csv como exemplo)
# ---------------------------------------------------------------
# Crie uma pasta de trabalho (workdir) para facilitar leitura/escrita
setwd("/caminho/para/pasta")  # opcional — prefira usar o painel do RStudio

# Exemplo: ler um CSV (substitua pelo nome do seu arquivo)
data <- read.csv("dados.csv", stringsAsFactors = FALSE)

# Para fins didáticos, vamos criar um data.frame de exemplo:
data <- data.frame(
  mun_nome = c("A", "A", "B", "B", "C"),
  Year = c(2020, 2020, 2020, 2021, 2021),
  Month = c(1, 2, 1, 1, 2),
  temperatura_c = c(26.5, 27.2, 28.1, 27.9, 26.8),
  precipitacao_mmdia = c(5, 0, 10, 2, 20),
  casos_dengue = c(12, 25, 8, 15, 30)
)

head(data)
str(data)
class(data)

# salvar um CSV
write.csv(data, "dados_saida.csv", row.names = FALSE)

# visualizar (RStudio) — lembre de usar o mesmo nome do objeto
View(data)

# criar uma nova variável
data$x1 <- data$temperatura_c / 2
head(data)

# remover variável
data$x1 <- NULL

# ---------------------------------------------------------------
# 6. PACOTES (instalar vs carregar)
# ---------------------------------------------------------------
# Um pacote é um conjunto de funções. Instale só quando necessário.
install.packages("dplyr")   # faça isso apenas uma vez
library(dplyr)

# usar dplyr para sumarizar (muito usado em análises ambientais)
data2 <- data %>%
  group_by(mun_nome, Year, Month) %>%
  summarise(
    precipitacao_mm = sum(precipitacao_mmdia, na.rm = TRUE),
    temperatura_c = mean(temperatura_c, na.rm = TRUE),
    casos_dengue = sum(casos_dengue, na.rm = TRUE)
  ) %>%
  ungroup()

data2

# Exercício: filtre apenas linhas do municipio 'A' e Year = 2020

# ---------------------------------------------------------------
# 7. MEDIDAS DE POSIÇÃO E DISPERSÃO
# ---------------------------------------------------------------
mean(data$temperatura_c)
median(data$precipitacao_mmdia)
summary(data)

# moda (maneira simples — cuidado se houver empates)
moda <- as.data.frame(table(data$temperatura_c))
moda
moda[moda$Freq == max(moda$Freq), ]

# percentis
quantile(data$temperatura_c, probs = c(0.25, 0.5, 0.75))
quantile(data$precipitacao_mmdia, probs = 0.95)

# variância e desvio padrão
var(data$temperatura_c)
sd(data$temperatura_c)

# histograma simples
hist(data$temperatura_c, main = "Histograma — Temperatura (°C)",
     xlab = "Temperatura (°C)", ylab = "Frequência", breaks = 8)

# histograma mais elaborado (sem fixar cores para evitar dependência)
hist(data$temperatura_c, main = "Histograma Temperatura",
     xlab = "Temperatura (°C)", ylab = "Frequência", breaks = 8)
abline(v = mean(data$temperatura_c), lwd = 2)
abline(v = median(data$temperatura_c), lwd = 2, lty = 2)

# ---------------------------------------------------------------
# 8. GRÁFICOS BÁSICOS (relação clima x saúde)
# ---------------------------------------------------------------
#Correlação de Pearson
cor(data$temperatura_c, data$casos_dengue, method = "pearson")

# Scatter plot: Temperatura x Casos de Dengue
plot(data$temperatura_c, data$casos_dengue,
     main = "Temperatura vs Casos de Dengue",
     xlab = "Temperatura (°C)", ylab = "Casos de Dengue",
     pch = 19)

# Adicionar uma linha de tendência (regressão simples)
modelo1 <- lm(casos_dengue ~ temperatura_c, data = data)
abline(modelo1, lwd = 2)
summary(modelo1)

# Série temporal (agregada por tempo)
data_ts <- data %>%
  arrange(Year, Month) %>%
  mutate(YearMonth = paste(Year, sprintf("%02d", Month), sep = "-"))

data_ts$YearMonth <- as.Date(paste0(data_ts$YearMonth, "-01"))
plot(data_ts$YearMonth, data_ts$casos_dengue, type = "b",
     main = "Casos de Dengue ao longo do tempo",
     xlab = "Ano-Mês", ylab = "Casos",
     las = 2, cex.axis = 0.8, col = "blue", pch = 19)

# ---------------------------------------------------------------
# 9. TABELAS RESUMO
# ---------------------------------------------------------------
resumo_mun <- data %>%
  group_by(mun_nome) %>%
  summarise(
    casos_total = sum(casos_dengue, na.rm = TRUE),
    temp_media = mean(temperatura_c, na.rm = TRUE),
    precip_total = sum(precipitacao_mmdia, na.rm = TRUE)
  )

resumo_mun

# FIM — PARTE_1

  
