#PARTE 1. Revisão
#Reabrir o Dataset
data=read.csv("dados.csv")

#Vamos filtrar os dados para manter apenas os dados de um municipio
natal=subset(data,data$mun_nome=="NATAL")

#2. Normalidade-------------------------------------------------------
#Vamos verificar a normalidade pelo teste de Shapiro-Wilk
#Instalar e habilitar pacotes
install.packages("nortest")
library(nortest)
#Rodar e visualizar o teste
teste=shapiro.test(natal$temperatura_c)
teste
##Aparentemente a temperatura não tem uma distribuição normal.
#Concluímos que não pressuposto de linearidade nesta varíavel

#3.Medidas de Relação--------------------------------------------

#Calcular Correlação de Pearson
cor.test(data$temperatura_c,data$umidade_relativa_percentual,method='pearson')
#Calcular Correlação de Spearman
cor.test(data$temperatura_c,data$umidade_relativa_percentual,method='spearman')

#Vamos plotar um diagrama de Dispersão simples
install.packages("ggplot2")
library(ggplot2)
##Usando a função ggplot podemos observar a relação gráfica entre as variáveis
ggplot(data, aes(y = temperatura_c, x = umidade_relativa_percentual)) +
  geom_point(shape = 1, size = 0.5,color="red",fill="red")+
  xlab("Umidade Relativa do Ar(%)")+
  ylab("Temperatura do Ar (°C)")

##Plotar Scatterplot de correlações
#Instalar e abrir pacote "PerformanceAnalytics
install.packages("PerformanceAnalytics")
library(PerformanceAnalytics)
#Plotar Scatterplot
chart.Correlation(data[, 10:19], histogram = TRUE, pch = "+")

#4.Regressões --------------------------------------------
#Calculo básico -> Primeira variável =Y Segunda variável = X
modelo=lm(natal$umidade_relativa_percentual ~ natal$temperatura_c)
#Informações do Modelo
summary(modelo)
#Vamos extrair o valor modelado e compara-lo com os reais
df1.Temp = as.data.frame(modelo$fitted)
df1=cbind(natal$umidade_relativa_percentual,df1.Temp)
colnames(df1) = c("Umidade","Modelada")
df1$erro=df1$Umidade - df1$Modelada
#Agora o calculo do erro quadrático
df1$erroq=df1$erro^2
eqm=mean(df1$erroq)
sqrt(eqm)

#Regress?o Linear Multipla
modelom=lm(data$pm25_ugm3 ~ data$temperatura_c + data$precipitacao_mmdia + data$umidade_relativa_percentual + data$vento_velocidade_ms)
summary(modelom)

# Regressão Aditiva Generalizada (GAM)----------------------------------------------------------------
install.packages("mgcv")
library(mgcv)
modelogam=gam(data$pm25_ugm3 ~ data$temperatura_c + data$precipitacao_mmdia + data$umidade_relativa_percentual + data$vento_velocidade_ms)
summary(modelogam)

#Parte 2.Modelos com dados de Meio Ambiente e Saúde -> Exemplo de Santa Cruz/RN
# 1. Carregar dados
# ============================================================
# 🌎 CURSO: Modelagem da dengue e variáveis climáticas
# 📘 Objetivo: Relacionar casos de dengue com clima (chuva, temperatura, umidade)
# ============================================================

# --- 1. Carregar pacotes necessários ---
library(tidyr)
library(readxl)
library(dplyr)
library(lubridate)
library(MASS)      # para modelo binomial negativo
library(pscl)      # para modelo ZINB
library(broom)     # para organizar resultados
library(ggplot2)

# --- 2. Importar os dados ---
df <- read_excel("dados_sc.xlsx")

# Visualizar estrutura e tipos das variáveis
str(df)

# Conferir valores ausentes (NA)
colSums(is.na(df))

# Conferir se há variáveis sem variação (constantes)
sapply(df, function(x) length(unique(x)))

# --- 3. Criar coluna de data e estação do ano ---

df <- df %>%
  mutate(
    # Cria uma data com base em ano + semana epidemiológica
    data = as.Date(paste(ano, semana, 1, sep = "-"), format = "%Y-%U-%u"),
    
    # Define a estação do ano a partir do mês
    estacao = case_when(
      month(data) %in% c(12, 1, 2)  ~ "verao",
      month(data) %in% c(3, 4, 5)   ~ "outono",
      month(data) %in% c(6, 7, 8)   ~ "inverno",
      month(data) %in% c(9, 10, 11) ~ "primavera"
    )
  )

# --- 4. Garantir que variáveis climáticas sejam numéricas ---
df <- df %>%
  mutate(across(c(prec, tmed, ur, dengue), as.numeric))

# --- 5. Especificar as variáveis explicativas ---
variaveis_clima <- c("prec", "tmed", "ur")
form <- as.formula(paste("dengue ~", paste(variaveis_clima, collapse = " + ")))

# --- 6. Ajustar modelo Binomial Negativo ---
# Este modelo é indicado quando temos contagem de casos (dados discretos)
# e há sobredispersão (a variância é maior que a média).

modelo_nb <- glm.nb(form, data = df)

summary(modelo_nb)

# --- 7. Calcular Razão de Incidência (IRR) ---
# IRR = exp(coeficiente). Indica o quanto a taxa de incidência muda
# para cada unidade de aumento da variável climática.

exp(cbind(IRR = coef(modelo_nb), confint(modelo_nb)))

# --- 8. Testar modelo Zero-Inflated (ZINB) ---
# O modelo ZINB (Zero-Inflated Negative Binomial) é útil quando há
# muitas semanas com zero casos de dengue (excesso de zeros).

modelo_zinb <- zeroinfl(form, data = df, dist = "negbin")

# --- 10. Comparar AIC entre os modelos NB e ZINB ---
# 📊 O AIC (Akaike Information Criterion) mede a qualidade do modelo.
# Quanto MENOR o AIC, melhor o equilíbrio entre ajuste e complexidade.
# A fórmula considera o logaritmo da verossimilhança e penaliza modelos muito complexos.

AIC(modelo_nb, modelo_zinb)

# --- 10. Visualizar IRR (Forest plot) ---

res_irr <- broom::tidy(modelo_nb, conf.int = TRUE, exponentiate = TRUE)

ggplot(res_irr %>% filter(term != "(Intercept)"),
       aes(x = term, y = estimate, ymin = conf.low, ymax = conf.high)) +
  geom_pointrange(color = "blue") +
  geom_hline(yintercept = 1, linetype = 2, color = "red") +
  coord_flip() +
  labs(y = "IRR (Razão de Incidência)", x = "Variável Climática",
       title = "Efeitos das variáveis climáticas sobre casos de dengue") +
  theme_minimal()

# --- 12. Criar variáveis defasadas (lags) ---
# As variáveis climáticas podem influenciar a dengue com atraso (1 a 4 semanas).

df_lags <- df %>%
  arrange(ano, semana) %>%
  mutate(
    prec_lag1 = lag(prec, 1),
    prec_lag2 = lag(prec, 2),
    prec_lag3 = lag(prec, 3),
    prec_lag4 = lag(prec, 4),
    ur_lag1   = lag(ur, 1),
    ur_lag2   = lag(ur, 2),
    ur_lag3   = lag(ur, 3),
    ur_lag4   = lag(ur, 4)
  )

# --- 13. Avaliar o efeito defasado ---
lags <- 1:4
resultados <- data.frame()

for (lag in lags) {
  modelo <- glm.nb(dengue ~ 
                     get(paste0("prec_lag", lag)) + 
                     get(paste0("ur_lag", lag)) + 
                     tmed, 
                   data = df_lags)
  
  coefs <- summary(modelo)$coefficients
  coefs <- coefs[-1, , drop=FALSE]  # remover intercept
  coefs <- data.frame(
    variavel = rownames(coefs),
    Estimate = coefs[, "Estimate"],
    SE = coefs[, "Std. Error"],
    lag = lag
  )
  
  resultados <- rbind(resultados, coefs)
}

# --- 14. Calcular IRR e IC95% ---
resultados <- resultados %>%
  mutate(IRR = exp(Estimate),
         lower = exp(Estimate - 1.96*SE),
         upper = exp(Estimate + 1.96*SE),
         variavel = gsub("_lag\\d+", "", variavel),
         lag = paste0("Lag ", lag))

# --- 15. Gráfico de IRR por defasagem ---
ggplot(resultados, aes(x = lag, y = IRR, color = variavel, group = variavel)) +
  geom_point(size = 3) +
  geom_line() +
  geom_errorbar(aes(ymin = lower, ymax = upper), width = 0.2) +
  labs(title = "Variação da Razão de Incidência (IRR) com o tempo de defasagem",
       x = "Defasagem (semanas)",
       y = "Razão de Incidência (IRR)",
       color = "Variável Climática") +
  scale_color_manual(
    values = c("prec" = "blue", "tmed" = "green", "ur" = "orange"),
    labels = c("prec" = "Precipitação", "tmed" = "Temperatura média", "ur" = "Umidade relativa")
  ) +
  theme_minimal()

#PARTE 3. BANCOS DE DADOS ON-LINE-----------------------------
#Instalar Pacote
install.packages("ipeadatar")
install.packages("tmap")
#Acionar pacote
library(ipeadatar)
library(tmap)
devtools::install_github("ipeaGIT/geobr", subdir = "r-package")
library(geobr)

## Vamos explorar os dados do IPEA
#analisar temas disponiveis
temas=available_subjects(language =  "br")
#Analisar series de dados disponiveis
series=available_series(language = "br")
#Filtrar s?ries de dados por temas
series_datasus=subset(series,source == 'DATASUS')
#Buscar dados -> Analfabetismo
Homicidio=ipeadata("HOMIC", language = c("en", "br"), quiet = FALSE)
#Filtrar Dados por estado
HOMI_MA=subset(Homicidio,tcode >=2100000 & tcode<=2200000)
#Filtrar Dados por Pesquisa
HOMI_MA_2022=subset(HOMI_MA,date=="2022-01-01")

#Associar a Mapa usando o GEOBR

##Extrair malha do RN
MA=read_municipality(code_muni = 21,year = 2022,simplified = TRUE,showProgress = TRUE)
plot(MA)
##Juntando SHPS + informações baixadas
shp_homi_ma <- merge(x = MA,
                     y = HOMI_MA_2022,
                     by.x = "code_muni",
                     by.y = "tcode")
#Plotagem Basica
tm_shape(shp = shp_homi_ma) +
  tm_fill(col = "value", palette = "Greens",style="quantile")

#Outra opção
tm_shape(shp_homi_ma) +
  tm_fill(
    col = "value",
    palette = "Greens",
    style = "fixed",                # define intervalos fixos
    breaks = seq(0, max(shp_homi_ma$value, na.rm = TRUE), by = 10),  # intervalo de 10
    title = "Número de casos"       # título da legenda
  ) +
  tm_borders()     


#Exportar o SHP
install.packages("sf")
library(sf)

caminho_saida <- "C:/Users/franc/Downloads/NEPA_DIA_02/shp_homi_ma.shp"

st_write(shp_homi_ma, caminho_saida, delete_layer = TRUE)
